package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) throws Exception {
		
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		Employee emp= ac.getBean("emp",Employee.class);
		Department dept=ac.getBean("dept",Department.class);
		
		Person p=new Person();
		p.setPersonId(23);
		p.setPersonName("Kavya");
		
		emp.setPerson(p);
		
		dept.setDeptId(10);
		emp.setEmpId(1024);
		emp.getEmpId();
		dept.getDeptId();
		dept.setDeptName("HR");
		dept.getDeptName();
		Person p1= emp.getPerson();
	

		//emp.display();
		
		System.out.println("---- Done ----");
		
		
		
		
		
	}
}
