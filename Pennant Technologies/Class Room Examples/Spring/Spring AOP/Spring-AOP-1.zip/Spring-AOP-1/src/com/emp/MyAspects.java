package com.emp;

import java.awt.JobAttributes;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.Person;

@Component
@Aspect
public class MyAspects {

	@Before("execution(* com.*.set*(*))")
	public void fun1(JoinPoint jp) {

		System.out.println("---- Property About to modify at "
				+ jp.getSignature());
	}

	@Before("execution(* com.Employee.get*())")
	public void fun2() {
		System.out.println("---- getter method got called...");
	}

	@After("execution(* com.Employee.set*(*))")
	public void fun3() {
		System.out.println("----F3   After Property has modified...");
	}

	/*
	 * @AfterReturning(value="execution(* com.*.get*())",returning="abc") public
	 * void f4(JoinPoint jp,Integer abc){
	 * System.out.println("Got Data form "+jp.
	 * getSignature()+"  F4 Data is  "+abc);
	 * 
	 * }
	 * 
	 * @AfterReturning(value="execution(* com.*.get*())",returning="abc") public
	 * void f5(JoinPoint jp,String abc){
	 * System.out.println("Got Data form "+jp.getSignature
	 * ()+" F5 Data  is  "+abc);
	 * 
	 * }
	 * 
	 * 
	 * @AfterReturning(value="execution(* com.*.get*())",returning="abc") public
	 * void f6(JoinPoint jp,Person abc){
	 * System.out.println("Got Data form "+jp.getSignature
	 * ()+" F6 Data  is  "+abc);
	 * 
	 * }
	 */

	@AfterReturning(value = "execution(* com.*.get*())", returning = "abc")
	public void f7(JoinPoint jp, Object abc) {
		System.out.println("Got Data form " + jp.getSignature()
				+ " F7 Data  is  " + abc);

	}

	@AfterThrowing(value = "execution(* com.*.display())", throwing = "abc")
	public void f8(JoinPoint jp, Object abc) {
		System.out.println("Got Exception  form " + jp.getSignature()
				+ " F8 Exception  is  " + abc);

	}

	/*@Around("execution(* com.EmployeeIds.generateEmpId(*))")
	public Object f9(ProceedingJoinPoint point) throws Throwable {
		
		Object obj = point.proceed();
		
		System.out.println("---- >F9 "+point.getSignature() + " Called and Data is  " + obj);
		return obj;

	}*/

}
