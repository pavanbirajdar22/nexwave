package com;

import java.util.List;

public class Employee {

	private int empId;
	private String empName;
	private double salary;

	private Person person;

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	public void display() throws Exception{
		
		if(empId==1024)
		
				throw new Exception("1024 data is already given.");
		
		else
			System.out.println("-- empId is "+empId);
		//System.out.println("Displaying employees");
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
