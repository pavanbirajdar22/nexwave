package com;

public class EmployeeIds {

	public int generateEmpId(int empId) {
		return Math.abs(empId);
	}

}
